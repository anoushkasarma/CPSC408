1) The following identifying information:

a. Full name: Anoushka Sarma
b. Student ID: 2407033
c. Chapman email: sarma@chapman.edu
d. Course number and section: CPSC 408 - 01
e. Assignment or exercise number: Assignment 5 - RideShare App

2) A list of all source files submitted for the assignment

db_operations.py
helper.py
RideShare.py
RideShare.db
driver.csv
ride.csv
rider.csv
data-dump.sql
PNG Image.jpeg (ER Diagram)


3) A description of any known compile or runtime errors, code limitations, or deviations
from the assignment specification (if applicable)

  No known runtime errors or limitations or deviations

4) A list of all references used to complete the assignment, including peers (if applicable)

Ruby Link and I worked together on the logic and the code

5) Instructions for running the assignment. (Typically applicable in advanced courses using
build systems or third party libraries)

python3 RideShare.py