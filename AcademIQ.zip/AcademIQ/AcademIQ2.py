import mysql.connector
from helper import helper
from db_operations import db_operations
import pandas as pd
import streamlit as st
from sqlalchemy import create_engine

# Initialize db_operations
db_ops = db_operations()

# Database connection details
username = 'root'
password = 'CPSC408!'
hostname = 'localhost'
database = 'AcademIQ'

# Create the connection string for SQLAlchemy
connection_string = f'mysql+mysqlconnector://{username}:{password}@{hostname}/{database}'
engine = create_engine(connection_string)

# Establish connection using mysql.connector
conn = mysql.connector.connect(
    host="localhost",
    user="root",
    password="CPSC408!",
    auth_plugin='mysql_native_password',
    database="AcademIQ"
)

# Cursor
cur_obj = conn.cursor()

# Streamlit app title
st.title("ACADEMIQ")

# User type
user_type = st.sidebar.selectbox("Select User Type", ["Professor", "Student"])

#Professor Functionality

# Function to view courses for a professor
def view_courses(id):
    st.subheader("View all courses")
    query = '''
    SELECT * 
    FROM Courses
    WHERE teacherID = %(id)s;
    '''
    results = db_ops.select_query_params(query, {"id": id})
    df = pd.read_sql(query, conn, params={"id": id})
    st.dataframe(df, hide_index=True)

# Aggregate/Group By Query to view course average for a professor
def view_course_avg(id):
    dict = {}
    dict["id"] = id

    query = '''
    SELECT Courses.courseID, Courses.courseName, AVG(grade) as Average_Grade
    FROM Exams
    INNER JOIN Courses
       ON Exams.courseID = Courses.courseID
    WHERE Courses.teacherID = %(id)s
    GROUP BY Courses.courseID;
    '''
    df = pd.read_sql(query, conn, params=dict)

    # Show results in streamlit
    st.subheader("Course Average Grades")
    st.dataframe(df, hide_index=True)

# Creates a new course
# Uses a transaction 
# Adds a student to a new course and then adds both to the enrollments table
def create_course(id):
    subject = st.text_input("Enter the subject:")
    term = st.text_input("Enter the term:")
    startTime = st.text_input("Enter the start time:")
    name = st.text_input("Enter the course name:")
    query_student = '''SELECT studentID, name FROM Students;'''
    df = pd.read_sql(query_student, conn)
    st.dataframe(df, hide_index=True)
    sid = st.number_input("Enter the student ID to enroll in the course:", min_value=0, step=1)
    dict  = {"tID":id}
    dict["cName"] = name
    dict["subject"] = subject
    dict["term"] = term
    dict["startTime"] = startTime
    dict['sid'] = sid

    # Transaction
    if st.button("Create Course"):
        cur_obj.execute("START TRANSACTION")  # Start transaction
        cur_obj.execute("SAVEPOINT before_insert") #Savepoint
        query = '''
        INSERT INTO Courses(teacherID, subject, term, startTime, courseName)
        VALUES(%(tID)s, %(subject)s, %(term)s, %(startTime)s, %(cName)s);
        '''
        
        cur_obj.execute(query, dict)
        query = '''SELECT * 
        FROM Courses 
        ORDER BY courseID 
        DESC LIMIT 1;'''
        cur_obj.execute(query)
        result = cur_obj.fetchone()
        cID = int(result[0])
        dict['cID'] = cID
        enrollment = '''INSERT INTO Enrollments(courseID, studentID) VALUES(%(cID)s, %(sid)s)'''
        cur_obj.execute(enrollment, dict)
        conn.commit()  # Commit transaction
        st.success("Course created successfully!")
        conn.rollback()  # Rollback transaction 

# Function to export enrollment information
# Query with joins across 3 tables
def export_enrollment_info(id):
    dict = {}
    dict["id"] = id

    query = '''
    SELECT Courses.courseName, Courses.term, Courses.startTime, Students.name
    FROM Enrollments
    INNER JOIN Courses
    ON Enrollments.courseID = Courses.courseID
    INNER JOIN Students 
    ON Enrollments.studentID = Students.studentID
    WHERE teacherID = %(id)s;
    '''
    
    results = db_ops.select_query_params(query, dict)
    
    # Make into dataframe
    df = pd.DataFrame(results, columns=["Course Name", "Term", "Start", "Student Name"])

    # Display results in Streamlit 
    st.subheader("Enrollment Information")
    st.dataframe(df, hide_index=True)

    # Download Button
    csv = df.to_csv(index=False)
    st.download_button(
        label="Download Enrollment Information as CSV",
        data=csv,
        file_name='enrollment_info.csv',
        mime='text/csv',
    )
    
#View ratings for professors
def view_my_rating(id):
    st.subheader("View My Ratings")
    dict = {'id': id}

    query = '''SELECT difficultyRating, overallRating, review
               FROM Professor_Rating
               WHERE teacherID = %(id)s;
            '''

    results = db_ops.select_query_params(query, dict)

    # Display the results in a Streamlit dataframe
    if results:
        df = pd.read_sql(query, conn, params=dict)
        st.dataframe(df, hide_index=True)
    else:
        st.warning("No ratings found for you.")


# Function to update a grade with an Update Query
def update_grade(id):
    #show all courses
    view_courses(id)
    #get course ID of which grade to updae for
    cid = st.number_input("Enter the course ID to view exams:", min_value=0, step=1)
    query = '''
    SELECT Exams.examID, Students.name, Exams.grade
    FROM Exams
    INNER JOIN Students ON Exams.studentID = Students.studentID
    WHERE courseID = %(cid)s
    '''
    #show all exams
    df = pd.read_sql(query, conn, params={"cid": cid})
    st.dataframe(df, hide_index=True)

    eid = st.number_input("Enter the exam ID to update:", min_value=0, step=1)
    grade = st.number_input("Enter the new grade:", min_value=0, max_value=100, step=1)

    #update exam grade
    if st.button("Update Grade"):
        query = '''
        UPDATE Exams
        SET grade = %(grade)s
        WHERE examID = %(eid)s
        '''
        db_ops.modify_query_params(query, {"eid": eid, "grade": grade})

# Student Functionalities

# Function to view schedule for a student, Joins across multiple tables
def view_schedule(id):
    #Schedule for one student
    query = '''
    SELECT Courses.courseID, courseName, startTime, Professors.name, Professors.teacherID
    FROM Courses
    INNER JOIN Enrollments 
        ON Courses.courseID = Enrollments.courseID
    INNER JOIN Students 
        ON Enrollments.studentID = Students.studentID
    INNER JOIN Professors 
        ON Courses.teacherID = Professors.teacherID
    WHERE Enrollments.studentID = %(sid)s
    '''
    df = pd.read_sql(query, conn, params={"sid": id})
    st.dataframe(df, hide_index=True)

# Function to review a course and Update Course_Rating
def review_course(id):
    view_schedule(id)
    #Collect information
    cid = st.number_input("Enter the course ID you would like to review:", min_value=0, step=1)
    difRate = st.slider("Enter the difficulty rating for this course (1-5):", 1, 5, 1)
    overallRate = st.slider("Enter the overall rating for this course (1-5):", 1, 5, 1)
    review = st.text_area("Write a brief review on this course:")

    if st.button("Submit Review"):
        query = '''
        INSERT INTO Course_Rating(studentID, courseID, difficultyRating, overallRating, review)
        VALUES(%(sid)s, %(cid)s, %(difRate)s, %(overallRate)s, %(review)s)
        '''
        db_ops.modify_query_params(query, {"sid": id, "cid": cid, "difRate": difRate, "overallRate": overallRate, "review": review})
        st.success("Review added!")


# Function to review a professor and Update Prof_Rating
def review_prof(id):
    view_schedule(id)
    #Collect Information
    pid = st.number_input("Enter the professor ID you would like to review:", min_value=0, step=1)
    difRate = st.slider("Enter the difficulty rating for this professor (1-5):", 1, 5, 1)
    overallRate = st.slider("Enter the overall rating for this professor (1-5):", 1, 5, 1)
    review = st.text_area("Write a brief review on this professor:")

    if st.button("Submit Review"):
        query = '''
        INSERT INTO Professor_Rating(studentID, teacherID, difficultyRating, overallRating, review)
        VALUES(%(sid)s, %(pid)s, %(difRate)s, %(overallRate)s, %(review)s)
        '''
        db_ops.modify_query_params(query, {"sid": id, "pid": pid, "difRate": difRate, "overallRate": overallRate, "review": review})
        st.success("Review added!")


def viewSchedule(id):
   dict = {}
   dict["sid"] = id
   #joins enrollment, students and professors and courses
   query = '''SELECT Courses.courseID, courseName, term, startTime, Professors.name, Professors.teacherID
   FROM Courses
   INNER JOIN Enrollments 
   ON Enrollments.courseID = Courses.courseID
   INNER JOIN Students
   ON Enrollments.StudentID = Students.studentID
   INNER JOIN Professors
   ON Professors.teacherID = Courses.teacherID
   WHERE 
   Enrollments.studentID = %(sid)s;  
'''
   results = db_ops.select_query_params(query, dict)
   helper.pretty_print(results)
   df = pd.read_sql(query, conn, params=dict)
   st.dataframe(df, hide_index = True)
   return query

def viewCourseGrade(id):
   dict = {"sID":id}
   print("Choose a class you want to see your grade for: ")
   classes = viewSchedule(id)
   #Collect Info
   cID = st.number_input("Enter the courseID: ", min_value=0, step=1)
   dict["cID"] = cID 
   query = '''SELECT AVG(grade) AS avg_grade
   FROM Exams
   WHERE courseID = %(cID)s AND studentID = %(sID)s'''
   #results = db_ops.select_query_params(query, dict)

   #Show Average Grade
   st.subheader("Your average grade is: ")
   df = pd.read_sql(query,conn, params=dict)
   st.dataframe(df, hide_index = True)

#functionality to show All Courses
def viewAllCourses():
   query = '''SELECT courseName, courseID
   FROM Courses;'''
   df = pd.read_sql(query, conn)
   st.dataframe(df, hide_index = True)
   return query

#Functionality to show all Profs
def viewAllProfs():
   query = '''SELECT name, teacherID
   FROM Professors;'''
   df = pd.read_sql(query, conn)
   st.dataframe(df, hide_index = True)
   return query

#Uses a view for course ratings
def viewCourseRating(id):
    st.subheader("View ratings for a course: ")
    viewAllCourses()
    cID = st.number_input("Enter the courseID: ", min_value=0, step=1)
    dict = {"cID":cID}
    query = '''SELECT courseName, difficultyRating, overallRating, review 
   FROM vcourseratings
   WHERE courseID = %(cID)s;'''
    course_df = pd.read_sql(query,conn, params=dict)
    st.dataframe(course_df, hide_index = True)

#Uses a view for professor ratings
def viewProfRating(id):
    st.subheader("View ratings for a professor: ")
    viewAllProfs()
    tID = st.number_input("Enter the teacherID: ", min_value=0, step=1)
    dict = {"tID":tID}
    query = '''SELECT name, difficultyRating, overallRating, review
   FROM vprofrating
   WHERE teacherID = %(tID)s;'''
    prof_df = pd.read_sql(query,conn, params=dict)
    st.dataframe(prof_df, hide_index = True)


#subquery example, Delete A Course Rating
def deleteCourseRating(id):
    dict = {}
    dict["sID"] = id
    st.subheader("Your ratings: ")
    query = '''SELECT Course_Rating.courseRatingID,
       Courses.courseName,
       Professors.name,
       Course_Rating.difficultyRating,
       Course_Rating.overallRating,
       Course_Rating.review
      FROM Course_Rating
      INNER JOIN Courses ON Course_Rating.courseID = Courses.courseID
      INNER JOIN Professors ON Courses.teacherID = Professors.teacherID
      WHERE Courses.teacherID IN (SELECT teacherID FROM Courses WHERE courseID = Course_Rating.courseID)
      AND studentID = %(sID)s;'''
    df = pd.read_sql(query, conn, params=dict)
    st.dataframe(df, hide_index = True)
    crID = st.number_input("Select the Course Rating ID of the rating you would like to delete: ", min_value = 0, step=1)
    dict["crID"] = crID
    if st.button("Delete Rating"):
        delete_query = '''DELETE FROM Course_Rating WHERE courseRatingID = %(crID)s;'''
        db_ops.modify_query_params(delete_query,dict)
        st.success("Your rating was deleted successfully!")



# Main function to run the app
def main():
    #if professor
    if user_type == "Professor":
        professor_id = st.text_input("Enter Professor ID:")
        if professor_id:
            professor_id = int(professor_id)
            action = st.selectbox("Select an Action", [
                "View Courses", "Create Course", "Update Grade", "View Course Averages", 
                "Export Enrollment Info", "View My Rating"
            ])
            if action == "View Courses":
                view_courses(professor_id)
            elif action == "Create Course":
                create_course(professor_id)
            elif action == "Export Enrollment Info":
                export_enrollment_info(professor_id)
            elif action == "View Course Averages":
                view_course_avg(professor_id)
            elif action =="View My Rating":
                view_my_rating(professor_id)
            elif action == "Update Grade":
                update_grade(professor_id)
                

    #if student
    elif user_type == "Student":
        student_id = st.text_input("Enter Student ID:")
        if student_id:
            student_id = int(student_id)
            action = st.selectbox("Select an Action", [
                "View Schedule", "View Course Grade", "Review Professor", "Review Course", 
                "View Course Rating", "View Professor Rating", "Delete Course Rating"
            ])
            if action == "View Schedule":
                view_schedule(student_id)
            elif action == "View Course Grade":
                viewCourseGrade(student_id)
            elif action == "Review Course":
                review_course(student_id)
            elif action == "Review Professor":
                review_prof(student_id)
            elif action == "View Course Rating":
                viewCourseRating(student_id)
            elif action == "View Professor Rating":
                viewProfRating(student_id)
            elif action == "Delete Course Rating":
                deleteCourseRating(student_id)

# Run the main function
if __name__ == "__main__":
    main()
