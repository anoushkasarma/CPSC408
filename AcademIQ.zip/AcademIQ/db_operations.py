import mysql.connector
from helper import helper
import csv

class db_operations():
    # constructor with connection path to DB
    def __init__(self):
        self.connection = mysql.connector.connect(host="localhost",
        user="root",
        password="CPSC408!",
        auth_plugin='mysql_native_password',
        database="AcademIQ")
        #create cursor object
        self.cursor = self.connection.cursor()
        #Print out connection to verify and close
        print(self.connection)
        print("connection made...")



    # function to simply execute a DDL or DML query.
    # commits query, returns no results. 
    # best used for insert/update/delete queries with no parameters
    def modify_query(self, query):
        self.cursor.execute(query)
        self.connection.commit()

    # function to simply execute a DDL or DML query with parameters
    # commits query, returns no results. 
    # best used for insert/update/delete queries with named placeholders
    def modify_query_params(self, query, dictionary):
        self.cursor.execute(query, dictionary)
        self.connection.commit()

    # function to simply execute a DQL query
    # does not commit, returns results
    # best used for select queries with no parameters
    def select_query(self, query):
        self.cursor.execute(query)
        return self.cursor.fetchall()
    
    # function to simply execute a DQL query with parameters
    # does not commit, returns results
    # best used for select queries with named placeholders
    def select_query_params(self, query, dictionary):
        self.cursor.execute(query, dictionary)
        return self.cursor.fetchall()

    def select_query_params_trans(self, query, dictionary):
        try:
            self.connection.start_transaction()
            # Execute the transaction query
            self.cursor.execute(query, dictionary)

            # Fetch results if needed
            results = self.cursor.fetchall()

            return results

        except Exception as e:
            # Rollback the transaction if an error occurs
            self.connection.rollback()
            print("Error:", e)
            return None
        

    # function to return the value of the first row's 
    # first attribute of some select query.
    # best used for querying a single aggregate select 
    # query with no parameters
    def single_record(self, query):
        self.cursor.execute(query)
        return self.cursor.fetchone()[0]
    
    # function to return the value of the first row's 
    # first attribute of some select query.
    # best used for querying a single aggregate select 
    # query with named placeholders
    def single_record_params(self, query, dictionary):
        self.cursor.execute(query, dictionary)
        return self.cursor.fetchone()[0]
    
    # function to return a single attribute for all records 
    # from some table.
    # best used for select statements with no parameters
    def single_attribute(self, query):
        self.cursor.execute(query)
        results = self.cursor.fetchall()
        results = [i[0] for i in results]
        #results.remove(None)
        return results
    
    # function to return a single attribute for all records 
    # from some table.
    # best used for select statements with named placeholders
    def single_attribute_params(self, query, dictionary):
        self.cursor.execute(query,dictionary)
        results = self.cursor.fetchall()
        results = [i[0] for i in results]
        return results
    
    # function for bulk inserting records
    # best used for inserting many records with parameters
    def bulk_insert(self, query, data):
        self.cursor.executemany(query, data)
        self.connection.commit()
    
    def create_student_table(self):
        query = '''
        CREATE TABLE Students(
            studentID INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
            name VARCHAR(20) NOT NULL,
            birthDate VARCHAR(10) NOT NULL, 
            phoneNumber VARCHAR(10),
            hometown VARCHAR(150),
            academicStanding VARCHAR(10),
            major VARCHAR(50)
        );
        '''
        self.cursor.execute(query)
        self.connection.commit()
        print('Table Student Created')
    
    def create_professor_table(self):
        query = '''
        CREATE TABLE Professors(
            teacherID INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
            name VARCHAR(20) NOT NULL,
            email VARCHAR(50),
            department VARCHAR(50),
            degree VARCHAR(50),
            yearsTeaching INT
            );
            '''
        self.cursor.execute(query)
        self.connection.commit()
        print('Table Professor Created')

    def create_courses_table(self):
        query = '''
        CREATE TABLE Courses(
        courseID INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
        teacherID INT NOT NULL,
        FOREIGN KEY (teacherID) REFERENCES Professors(teacherID),
        subject VARCHAR(150),
        term VARCHAR(25),
        startTime VARCHAR(20)
        );
        '''
        self.cursor.execute(query)
        self.connection.commit()
        print('Table Courses Created')

    def create_exams_table(self):
        query = '''
        CREATE TABLE Exams(examID INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
        courseID INT NOT NULL,
        studentID INT NOT NULL,
        FOREIGN KEY (courseID) REFERENCES Courses(courseID),
        FOREIGN KEY (studentID) REFERENCES Students(studentID),
        grade INT
        );
        '''
        self.cursor.execute(query)
        self.connection.commit()
        print('Table Exam Created')

    def create_professor_rating_table(self):
        query = '''
        CREATE TABLE Professor_Rating(profRatingID INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
        studentID INT NOT NULL,
        teacherID INT NOT NULL,
        FOREIGN KEY (studentID) REFERENCES Students(studentID),
        FOREIGN KEY (teacherID) REFERENCES Professors(teacherID),
        difficultyRating INT,
        overAllRating INT,
        review VARCHAR(500)
        );
        '''
        self.cursor.execute(query)
        self.connection.commit()
        print('Table Prof Rating Created')
        
    def create_course_rating_table(self):
        query = '''
        CREATE TABLE Course_Rating(courseRatingID INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
        studentID INT NOT NULL,
        courseID INT NOT NULL,
        FOREIGN KEY (studentID) REFERENCES Students(studentID),
        FOREIGN KEY (courseID) REFERENCES Courses(courseID),
        difficultyRating INT,
        overAllRating INT,
        review VARCHAR(500)
        );
        '''
        self.cursor.execute(query)
        self.connection.commit()
        print('Table Course Rating Created')
    
    def create_enrollments_table(self):
        query = '''
        CREATE TABLE Enrollments(courseID INT NOT NULL,
        studentID INT NOT NULL,
        FOREIGN KEY (courseID) REFERENCES Courses(courseID),
        FOREIGN KEY (studentID) REFERENCES Students(studentID)
        );
        '''
        self.cursor.execute(query)
        self.connection.commit()
        print('Table Enrollments Created')
    
    def drop_table(self):
        query = '''
        DROP TABLE Exams;
        '''
        self.cursor.execute(query)
        self.connection.commit()
        print('Table Exam Dropped')


    # def populate_rider_table(self, filepath):
    #     data = helper.data_cleaner(filepath)
    #     attribute_count = len(data[0])
    #     placeholders = ("%s,"*attribute_count)[:-1]
    #     query = "INSERT INTO rider (name, phoneNumber, email) VALUES("+placeholders+")"
    #     self.bulk_insert(query, data)

    # def populate_driver_table(self, filepath):
    #     data = helper.data_cleaner(filepath)
    #     attribute_count = len(data[0])
    #     placeholders = ("%s,"*attribute_count)[:-1]
    #     query = "INSERT INTO driver (name, phoneNumber, email, mode) VALUES("+placeholders+")"
    #     self.bulk_insert(query, data)

    # def populate_ride_table(self, filepath):
   

    def pop_students(self,filepath):
        data = helper.data_cleaner(filepath)
        attribute_count = len(data[0])
        placeholders = ("%s,"*attribute_count)[:-1]
        query = "INSERT INTO Students(name, birthDate, phoneNumber, homeTown, academicStanding, major) VALUES("+placeholders+")"
        self.bulk_insert(query, data)

    def pop_profs(self,filepath):
        data = helper.data_cleaner(filepath)
        attribute_count = len(data[0])
        placeholders = ("%s,"*attribute_count)[:-1]
        query = "INSERT INTO Professors(name, email, department, degree, yearsTeaching) VALUES("+placeholders+")"
        self.bulk_insert(query, data)

    def pop_courses(self,filepath):
        data = helper.data_cleaner(filepath)
        attribute_count = len(data[0])
        placeholders = ("%s,"*attribute_count)[:-1]
        query = "INSERT INTO Courses(teacherID, subject, term, startTime) VALUES("+placeholders+")"
        self.bulk_insert(query, data)

    def pop_enrollments(self,filepath):
        data = helper.data_cleaner(filepath)
        attribute_count = len(data[0])
        placeholders = ("%s,"*attribute_count)[:-1]
        query = "INSERT INTO Enrollments(courseID, studentID) VALUES("+placeholders+");"
        self.bulk_insert(query, data)

    def pop_exams(self,filepath):
        data = helper.data_cleaner(filepath)
        attribute_count = len(data[0])
        placeholders = ("%s,"*attribute_count)[:-1]
        query = "INSERT INTO Exams(courseID, studentID, grade) VALUES("+placeholders+");"
        self.bulk_insert(query, data)
    
    def pop_profRating(self,filepath):
        data = helper.data_cleaner(filepath)
        attribute_count = len(data[0])
        placeholders = ("%s,"*attribute_count)[:-1]
        query = "INSERT INTO Professor_Rating(studentID, teacherID, difficultyRating, overallRating, review) VALUES("+placeholders+");"
        self.bulk_insert(query, data)
    
    def pop_courseRating(self,filepath):
        data = helper.data_cleaner(filepath)
        attribute_count = len(data[0])
        placeholders = ("%s,"*attribute_count)[:-1]
        query = "INSERT INTO Course_Rating(studentID, courseID, difficultyRating, overallRating, review) VALUES("+placeholders+");"
        self.bulk_insert(query, data)

    def export(self, query, dictionary):
        self.cursor.execute(query, dictionary)
        rows = self.cursor.fetchall()
        with open("enrollment_info.csv", 'w', newline='') as csvfile:
            csv_writer = csv.writer(csvfile)
            csv_writer.writerows(rows)
    






    # destructor that closes connection with DB
    def destructor(self):
        self.cursor.close()
        self.connection.close()



