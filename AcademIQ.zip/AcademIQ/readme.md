1) The following identifying information:

a. Full name: Anoushka Sarma, Ruby Link, Catherine Mckay
c. Chapman email: sarma@chapman.edu, rlink@chapman.edu, mckay@chapman.edu
d. Course number and section: CPSC 408 - 01
e. Assignment or exercise number: Final Project

2) A list of all source files submitted for the assignment

db_operations.py
helper.py
AcademIQ2.py
CourseRating.csv
Courses.csv
enrollment_info.csv
Enrollments.csv
Exams.csv
ProfessorRating.csv
Students.csv
Teachers.csv
AcademIQ_dump.sql
demo.webm



3) A description of any known compile or runtime errors, code limitations, or deviations
from the assignment specification (if applicable)

  No known runtime errors or limitations or deviations

4) A list of all references used to complete the assignment, including peers (if applicable)

 Demo from class

    Streamlit resources:
    https://docs.streamlit.io/develop/tutorials/databases/mssql 
    https://docs.streamlit.io/get-started/tutorials/create-an-app
    https://www.geeksforgeeks.org/a-beginners-guide-to-streamlit/

    Our friend Apoorva also helped us get started on the streamlit code, she is in the second section


5) Instructions for running the assignment. (Typically applicable in advanced courses using
build systems or third party libraries)

 streamlit run AcademIQ2.py

    input own username and password for database connection

Note: professorID = 2 has the most entires and will result in the best testing for the Professor actions

Downloads:
pip3 install pip3 install SQLAlchemy

