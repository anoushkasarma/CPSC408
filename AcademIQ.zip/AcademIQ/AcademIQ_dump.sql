-- MySQL dump 10.13  Distrib 8.3.0, for macos14.2 (x86_64)
--
-- Host: localhost    Database: AcademIQ
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Course_Rating`
--

DROP TABLE IF EXISTS `Course_Rating`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Course_Rating` (
  `courseRatingID` int NOT NULL AUTO_INCREMENT,
  `studentID` int NOT NULL,
  `courseID` int NOT NULL,
  `difficultyRating` int DEFAULT NULL,
  `overAllRating` int DEFAULT NULL,
  `review` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`courseRatingID`),
  KEY `studentID` (`studentID`),
  KEY `courseID` (`courseID`),
  CONSTRAINT `course_rating_ibfk_1` FOREIGN KEY (`studentID`) REFERENCES `Students` (`studentID`),
  CONSTRAINT `course_rating_ibfk_2` FOREIGN KEY (`courseID`) REFERENCES `Courses` (`courseID`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Course_Rating`
--

LOCK TABLES `Course_Rating` WRITE;
/*!40000 ALTER TABLE `Course_Rating` DISABLE KEYS */;
INSERT INTO `Course_Rating` VALUES (1,1,1,4,4,'This course is really hard but if you study and take notes it can be easy'),(2,2,2,2,3,'This course is easy but if you miss class your grade will be affected'),(3,3,3,5,5,'This course is really fun and you learn a lot even though it can be hard'),(5,3,3,4,5,'This class is so freaking hard what is mitosis');
/*!40000 ALTER TABLE `Course_Rating` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Courses`
--

DROP TABLE IF EXISTS `Courses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Courses` (
  `courseID` int NOT NULL AUTO_INCREMENT,
  `teacherID` int NOT NULL,
  `subject` varchar(150) DEFAULT NULL,
  `term` varchar(25) DEFAULT NULL,
  `startTime` varchar(20) DEFAULT NULL,
  `courseName` varchar(150) DEFAULT NULL,
  PRIMARY KEY (`courseID`),
  KEY `teacherID` (`teacherID`),
  KEY `idx_courseID` (`courseID`),
  CONSTRAINT `courses_ibfk_1` FOREIGN KEY (`teacherID`) REFERENCES `Professors` (`teacherID`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Courses`
--

LOCK TABLES `Courses` WRITE;
/*!40000 ALTER TABLE `Courses` DISABLE KEYS */;
INSERT INTO `Courses` VALUES (1,1,'MATH310','Fall2024','8/28/24','Calculus'),(2,2,'CPSC230','Fall2024','8/28/24','Python'),(3,3,'BIO200','Fall2024','8/28/24','Biology'),(7,1,'MUAHA','MROW','FALL','MROW'),(23,2,'SLAY100','FALL2025','8/31/24','Girlboss'),(25,1,'GIRL201','FALL2025','8/31','Girlboss'),(26,2,'HOR210','FALL2025','8/31/24','Horse'),(29,1,'MEOW100','FALL2024','8/31/23','How to Meow'),(30,1,'HEY100','FALL2024','8/31/24','How to say Hi'),(31,3,'CPSC308','FALL2024','8/31/24','Database'),(33,3,'BIOL330','FALL2025','8/31/24','AI Medicine'),(34,2,'BLAH100','SPRING2025','8/31/23','mufasa'),(35,2,'MATH179','FALL2025','8/21/24','Mathematics in Calculus');
/*!40000 ALTER TABLE `Courses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Enrollments`
--

DROP TABLE IF EXISTS `Enrollments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Enrollments` (
  `courseID` int NOT NULL,
  `studentID` int NOT NULL,
  KEY `courseID` (`courseID`),
  KEY `studentID` (`studentID`),
  CONSTRAINT `enrollments_ibfk_1` FOREIGN KEY (`courseID`) REFERENCES `Courses` (`courseID`),
  CONSTRAINT `enrollments_ibfk_2` FOREIGN KEY (`studentID`) REFERENCES `Students` (`studentID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Enrollments`
--

LOCK TABLES `Enrollments` WRITE;
/*!40000 ALTER TABLE `Enrollments` DISABLE KEYS */;
INSERT INTO `Enrollments` VALUES (1,1),(2,2),(3,3),(23,1),(31,2),(33,1),(34,6),(35,5);
/*!40000 ALTER TABLE `Enrollments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Exams`
--

DROP TABLE IF EXISTS `Exams`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Exams` (
  `examID` int NOT NULL AUTO_INCREMENT,
  `courseID` int NOT NULL,
  `studentID` int NOT NULL,
  `grade` int DEFAULT NULL,
  PRIMARY KEY (`examID`),
  KEY `courseID` (`courseID`),
  KEY `studentID` (`studentID`),
  CONSTRAINT `exams_ibfk_1` FOREIGN KEY (`courseID`) REFERENCES `Courses` (`courseID`),
  CONSTRAINT `exams_ibfk_2` FOREIGN KEY (`studentID`) REFERENCES `Students` (`studentID`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Exams`
--

LOCK TABLES `Exams` WRITE;
/*!40000 ALTER TABLE `Exams` DISABLE KEYS */;
INSERT INTO `Exams` VALUES (1,1,1,97),(2,2,2,98),(3,3,3,98),(4,1,1,87),(5,7,4,65),(6,31,2,78),(7,23,1,92),(8,33,1,88);
/*!40000 ALTER TABLE `Exams` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Professor_Rating`
--

DROP TABLE IF EXISTS `Professor_Rating`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Professor_Rating` (
  `profRatingID` int NOT NULL AUTO_INCREMENT,
  `studentID` int NOT NULL,
  `teacherID` int NOT NULL,
  `difficultyRating` int DEFAULT NULL,
  `overAllRating` int DEFAULT NULL,
  `review` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`profRatingID`),
  KEY `studentID` (`studentID`),
  KEY `teacherID` (`teacherID`),
  CONSTRAINT `professor_rating_ibfk_1` FOREIGN KEY (`studentID`) REFERENCES `Students` (`studentID`),
  CONSTRAINT `professor_rating_ibfk_2` FOREIGN KEY (`teacherID`) REFERENCES `Professors` (`teacherID`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Professor_Rating`
--

LOCK TABLES `Professor_Rating` WRITE;
/*!40000 ALTER TABLE `Professor_Rating` DISABLE KEYS */;
INSERT INTO `Professor_Rating` VALUES (1,1,1,4,3,'This professor is hard and is not understanding'),(2,2,2,3,4,'This professor is super understanding and will help you succeed if you go to office hours'),(3,3,3,2,5,'This professor cares about students and learning'),(4,1,1,1,1,'worst prof ever'),(5,2,2,2,3,'She\'s cool or whatever'),(6,2,2,2,3,'She\'s cool or whatever'),(7,2,2,2,4,'She\'s so nice!'),(8,2,2,3,4,'she is so mean made me cry so bad');
/*!40000 ALTER TABLE `Professor_Rating` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Professors`
--

DROP TABLE IF EXISTS `Professors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Professors` (
  `teacherID` int NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `email` varchar(50) DEFAULT NULL,
  `department` varchar(50) DEFAULT NULL,
  `degree` varchar(50) DEFAULT NULL,
  `yearsTeaching` int DEFAULT NULL,
  PRIMARY KEY (`teacherID`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Professors`
--

LOCK TABLES `Professors` WRITE;
/*!40000 ALTER TABLE `Professors` DISABLE KEYS */;
INSERT INTO `Professors` VALUES (1,'Steven Roberts','roberts@chapman.edu','Mathematics','PhD',10),(2,'Lauren Wright','wright@chapman.edu','Engineering','PhD',8),(3,'James Harper','harper@chapman.edu','Science','Masters',2),(4,'Mike Lee','lee@chapman.edu','English','Bachelors',4),(5,'Cynthia Kay','kay@chapman.edu','Business','Masters',1);
/*!40000 ALTER TABLE `Professors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Students`
--

DROP TABLE IF EXISTS `Students`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Students` (
  `studentID` int NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `birthDate` varchar(10) NOT NULL,
  `phoneNumber` varchar(10) DEFAULT NULL,
  `hometown` varchar(150) DEFAULT NULL,
  `academicStanding` varchar(10) DEFAULT NULL,
  `major` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`studentID`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Students`
--

LOCK TABLES `Students` WRITE;
/*!40000 ALTER TABLE `Students` DISABLE KEYS */;
INSERT INTO `Students` VALUES (1,'John Doe','1/21/04','1234567890','San Fransisco','Freshman','Mathematics'),(2,'Mary Smith','5/12/03','2345678900','Orange','Junior','Data Science'),(3,'Catheirine McKay','8/19/02','3456789900','Huntington Beach','Senior','Computer Science'),(4,'Mia Sandberg','4/19/02','3336667778','Lake Oswego','Sophomore','Business'),(5,'Ruby Link','12/19/2002','3035976142','Boulder','Junior','Data Science'),(6,'Anoushka Sarma','12/06/2002','9702863150','Fort Collins','Junior','Finance');
/*!40000 ALTER TABLE `Students` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `vcourseratings`
--

DROP TABLE IF EXISTS `vcourseratings`;
/*!50001 DROP VIEW IF EXISTS `vcourseratings`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `vcourseratings` AS SELECT 
 1 AS `courseName`,
 1 AS `courseID`,
 1 AS `difficultyRating`,
 1 AS `overallRating`,
 1 AS `review`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `vprofrating`
--

DROP TABLE IF EXISTS `vprofrating`;
/*!50001 DROP VIEW IF EXISTS `vprofrating`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `vprofrating` AS SELECT 
 1 AS `name`,
 1 AS `teacherID`,
 1 AS `difficultyRating`,
 1 AS `overallRating`,
 1 AS `review`*/;
SET character_set_client = @saved_cs_client;

--
-- Final view structure for view `vcourseratings`
--

/*!50001 DROP VIEW IF EXISTS `vcourseratings`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vcourseratings` AS select `courses`.`courseName` AS `courseName`,`courses`.`courseID` AS `courseID`,`course_rating`.`difficultyRating` AS `difficultyRating`,`course_rating`.`overAllRating` AS `overallRating`,`course_rating`.`review` AS `review` from (`course_rating` join `courses` on((`courses`.`courseID` = `course_rating`.`courseID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vprofrating`
--

/*!50001 DROP VIEW IF EXISTS `vprofrating`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vprofrating` AS select `p`.`name` AS `name`,`p`.`teacherID` AS `teacherID`,`pr`.`difficultyRating` AS `difficultyRating`,`pr`.`overAllRating` AS `overallRating`,`pr`.`review` AS `review` from (`professor_rating` `pr` join `professors` `p` on((`p`.`teacherID` = `pr`.`teacherID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-05-17 17:44:44
